﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Home : Form
    {
        Utils utils;
        User userCookies;
        UserList userList;
        FlightList flightList;
        BookingList bookingList;
        public Home()
        {
            InitializeComponent();
        }
        public Home(User userCookies, UserList userList, FlightList flightList, BookingList bookingList)
        {
            this.userCookies = userCookies;
            this.userList = userList;
            this.flightList = flightList;
            this.bookingList = bookingList;
            this.utils = new Utils();
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            //Initialize Flight Table
            InitializeDataGridView();
            InitializeDataGridViewConnectingFlight();
            dataGridViewFlights.Rows.Clear();
            dataGridViewConnectingFlight.Rows.Clear();
            // Populate the list box with flight details
            List<Flight> flights = flightList.getFlightList();
            foreach (Flight flight in flights)
            {
                int rowIndex = dataGridViewFlights.Rows.Add(
                    flight.getId(),
                    flight.getFlightName(),
                    flight.getAirline(),
                    flight.getArrival(),
                    flight.getDestination()
                );
                dataGridViewFlights.Rows[rowIndex].Tag = flight;
            }
            dataGridViewFlights.CellContentClick += dataGridViewFlights_CellContentClick_AddFlight;
            dataGridViewConnectingFlight.CellContentClick += dataGridViewConnectingFlight_CellContentClick;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string arrivalFilter = textBox1.Text.Trim();
            string destinationFilter = textBox2.Text.Trim();
            string airlineFilter = textBox3.Text.Trim();

            List<Flight> filterFlightList = flightList.getFlightFromFilter(arrivalFilter, destinationFilter, airlineFilter);

            //Clean the initial List in GridView
            dataGridViewFlights.Rows.Clear();
            dataGridViewConnectingFlight.Rows.Clear();
            // Display new List
            foreach (Flight flight in filterFlightList)
            {
                int rowIndex = dataGridViewFlights.Rows.Add(
                    flight.getId(),
                    flight.getFlightName(),
                    flight.getAirline(),
                    flight.getArrival(),
                    flight.getDestination()
                );
                dataGridViewFlights.Rows[rowIndex].Tag = flight;
            }
            List<Tuple<Flight, Flight>> connectingFlightList = flightList.getConnectingFlightListFromFilter(arrivalFilter, destinationFilter, airlineFilter);
            if (connectingFlightList.Count > 0)
            {
                foreach (Tuple<Flight, Flight> connectingFlight in connectingFlightList)
                {
                    Flight firstFlight = connectingFlight.Item1;
                    Flight secondFlight = connectingFlight.Item2;
                    string trip = $"{firstFlight.getArrival()} => {firstFlight.getDestination()}, {secondFlight.getArrival()} => {secondFlight.getDestination()}";
                    int rowIndex = dataGridViewConnectingFlight.Rows.Add(
                        trip,
                        firstFlight.getId(),
                        firstFlight.getFlightName(),
                        secondFlight.getId(),
                        secondFlight.getFlightName()
                    );
                    dataGridViewConnectingFlight.Rows[rowIndex].Tag = connectingFlight;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BookedFlight bookedFlight = new BookedFlight(userCookies, flightList, bookingList);
            bookedFlight.Show();
            this.Hide();
            bookedFlight.FormClosed += (s, args) => this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
        private void dataGridViewFlights_CellContentClick_AddFlight(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            //Check if sender is from DataGridButtonColumn
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn
                && e.RowIndex >= 0)
            {
                //Get Flight from Column tag
                Flight selectedFlight = new Flight();
                selectedFlight = (Flight)dataGridViewFlights.Rows[e.RowIndex].Tag;
                int userId = userCookies.getId();
                int flightId = selectedFlight.getId();
                if (selectedFlight == null)
                {
                    MessageBox.Show("Flight empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (bookingList.hasBooking(userId, flightId, -1))
                {
                    MessageBox.Show("Already have booking", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (userId != 0 && flightId != null)
                        try
                        {
                            int newId = utils.GenerateNewRandomID(bookingList.getBookingIdList());
                            bookingList.addBooking(new Booking(newId, userId, flightId, -1, "straight"));
                            MessageBox.Show("Booking Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Unable to add booking!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                }
            }
        }
        private void dataGridViewConnectingFlight_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn
                && e.RowIndex >= 0)
            {
                Tuple<Flight, Flight> selectedConnectingFlight = (Tuple<Flight, Flight>)dataGridViewConnectingFlight.Rows[e.RowIndex].Tag;
                int userId = userCookies.getId();
                int firstFlightId = selectedConnectingFlight.Item1.getId();
                int secondFlightId = selectedConnectingFlight.Item2.getId();
                if (selectedConnectingFlight == null)
                {
                    MessageBox.Show("Flight empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (bookingList.hasBooking(userId, firstFlightId, secondFlightId))
                {
                    MessageBox.Show("Already have booking", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (firstFlightId > 0
                        && secondFlightId > 0
                        && firstFlightId != secondFlightId)
                    {
                        try
                        {
                            int newId = utils.GenerateNewRandomID(bookingList.getBookingIdList());
                            bookingList.addBooking(new Booking(newId, userId, firstFlightId, secondFlightId, "connecting"));
                            MessageBox.Show("Booking Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Unable to add booking!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }

            }

            
        }
    }
}
