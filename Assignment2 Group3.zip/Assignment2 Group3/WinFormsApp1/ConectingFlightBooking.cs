﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public class ConectingFlightBooking
    {
        private Flight initialFlight;
        private Flight connectingFlight;
        public ConectingFlightBooking() { }

        public ConectingFlightBooking(Flight initialFlight, Flight connectingFlight)
        {
            this.initialFlight = initialFlight;
            this.connectingFlight = connectingFlight;
        }

        public Flight getInitialFlight()
        {
            return this.initialFlight;
        }

        public void setInitialFlight(Flight initialFlight)
        {
            this.initialFlight = initialFlight;
        }

        public Flight getConnectingFlight()
        {
            return this.connectingFlight;
        }

        public void setConnectingFlight(Flight connectingFlight)
        {
            this.connectingFlight = connectingFlight;
        }
    }
}
