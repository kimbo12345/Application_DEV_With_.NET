﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace WinFormsApp1
{
    public class User
    {
        private int id { get; set; }
        private string name { get; set; }
        private string username { get; set; }
        private string password { get; set; }
        private string role { get; set; }
        // No Args Constructor
        public User() {
        }

        //All Args Constructor
        public User(int id, string name, string username, string password, string role)
        {
            this.id = id;
            this.name = name;
            this.username = username;
            this.password = password;  
            this.role = role;
        }

        //Functions
        public bool isUsername(string username)
        {
            if (this.username == username) 
                return true;
            return false;
        }

        public bool isPassword(string password)
        {
            if (this.password == password)
                return true;
            return false;
        }

        public void loadUser(string dataLine)
        {
            string[] tempUser = dataLine.Split('|');
            this.id = Convert.ToInt32(tempUser[0]);
            this.name = tempUser[1];
            this.username = tempUser[2];   
            this.password = tempUser[3];
            this.role = tempUser[4];
        }
        //Getter and Setter
        public int getId()
        {
            return this.id;
        }
        public void setId(int id)
        {
            this.id = id;
        }
        public string getName()
        {
            return this.name;
        }
        public void setName(string name)
        {
            this.name = name;
        }
        public string getUsername()
        {
            return this.username;
        }
        public void setUsername(string username)
        {
            this.username = username;
        }
        public string getPassword()
        {
            return this.password;
        }
        public void setPassword(string password)
        {
            this.password = password;
        }
        public string getRole()
        {
            return this.role;
        }
        public void setRole()
        {
            this.role = role;
        }
    }
}

*/


namespace WinFormsApp1
{
    public class User
    {
        private int id { get; set; }
        private string name { get; set; }
        private string username { get; set; }
        private string password { get; set; }
        private string role { get; set; }
        private List<string> editHistory; // To store change logs

        // Constructors
        public User()
        {
            editHistory = new List<string>();
        }

        public User(int id, string name, string username, string password, string role)
        {
            this.id = id;
            this.name = name;
            this.username = username;
            this.password = password;
            this.role = role;
            editHistory = new List<string>();
        }

        // Functions
        public bool isUsername(string username) => this.username == username;
        public bool isPassword(string password) => this.password == password;

        public void loadUser(string dataLine)
        {
            string[] tempUser = dataLine.Split('|');
            this.id = Convert.ToInt32(tempUser[0]);
            this.name = tempUser[1];
            this.username = tempUser[2];
            this.password = tempUser[3];
            this.role = tempUser[4];
        }

        public void LogEdit(string change)
        {
            editHistory.Add($"{DateTime.Now}: {change}");
        }

        public List<string> GetEditHistory() => editHistory;

        // Getters and Setters with audit logging
        public int getId() => this.id;
        public void setId(int id) { LogEdit($"Id changed from {this.id} to {id}"); this.id = id; }

        public string getName() => this.name;
        public void setName(string name) { LogEdit($"Name changed from {this.name} to {name}"); this.name = name; }

        public string getUsername() => this.username;
        public void setUsername(string username) { LogEdit($"Username changed from {this.username} to {username}"); this.username = username; }

        public string getPassword() => this.password;
        public void setPassword(string password) { LogEdit("Password changed"); this.password = password; }

        public string getRole() => this.role;
        public void setRole(string role) { LogEdit($"Role changed from {this.role} to {role}"); this.role = role; }
    }
}
