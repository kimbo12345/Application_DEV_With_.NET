﻿using System;
using System.Windows.Forms;

using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace WinFormsApp1
{
    public partial class EditForm : Form
    {
        private User currentUser;
        private Flight currentFlight;
        private Booking currentBooking;
        private string editType;

        public EditForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            editType = "User";
            LoadUserData();
            LoadAuditTrail(currentUser.GetEditHistory()); // Audit Trail 로드
        }

        public EditForm(Flight flight)
        {
            InitializeComponent();
            currentFlight = flight;
            editType = "Flight";
            LoadFlightData();
            LoadAuditTrail(currentFlight.GetEditHistory()); // Audit Trail 로드
        }

        public EditForm(Booking booking)
        {
            InitializeComponent();
            currentBooking = booking;
            editType = "Booking";
            LoadBookingData();
            LoadAuditTrail(currentBooking.GetEditHistory()); // Audit Trail 로드
        }

        private void LoadUserData()
        {
            lblField1.Text = "ID";
            lblField2.Text = "Name";
            lblField3.Text = "Username";
            lblField4.Text = "Password";
            lblField5.Text = "Role";

            txtField1.Text = currentUser.getId().ToString();
            txtField2.Text = currentUser.getName();
            txtField3.Text = currentUser.getUsername();
            txtField4.Text = currentUser.getPassword();
            txtField5.Text = currentUser.getRole();

            txtField1.ReadOnly = true;
        }

        private void LoadFlightData()
        {
            lblField1.Text = "Flight ID";
            lblField2.Text = "Flight Name";
            lblField3.Text = "Airline";
            lblField4.Text = "Arrival";
            lblField5.Text = "Destination";

            txtField1.Text = currentFlight.getId().ToString();
            txtField2.Text = currentFlight.getFlightName();
            txtField3.Text = currentFlight.getAirline();
            txtField4.Text = currentFlight.getArrival();
            txtField5.Text = currentFlight.getDestination();

            txtField1.ReadOnly = true;
        }

        private void LoadBookingData()
        {
            lblField1.Text = "Booking ID";
            lblField2.Text = "User ID";
            lblField3.Text = "Flight ID";
            lblField4.Text = "Connecting Flight ID";
            lblField5.Text = "Booking Type";

            txtField1.Text = currentBooking.getId().ToString();
            txtField2.Text = currentBooking.getUserId().ToString();
            txtField3.Text = currentBooking.getFlightId().ToString();
            txtField4.Text = currentBooking.getConnectingFlightId().ToString();
            txtField5.Text = currentBooking.getBookingType();

            txtField1.ReadOnly = true;
        }

        private void LoadAuditTrail(List<string> editHistory)
        {
            lstAuditTrail.Items.Clear();
            foreach (string history in editHistory)
            {
                lstAuditTrail.Items.Add(history);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                switch (editType)
                {
                    case "User":
                        currentUser.setName(txtField2.Text);
                        currentUser.setUsername(txtField3.Text);
                        currentUser.setPassword(txtField4.Text);
                        currentUser.setRole(txtField5.Text);
                        break;

                    case "Flight":
                        currentFlight.setFlightName(txtField2.Text);
                        currentFlight.setAirline(txtField3.Text);
                        currentFlight.setArrival(txtField4.Text);
                        currentFlight.setDestination(txtField5.Text);
                        break;

                    case "Booking":
                        currentBooking.setUserId(int.Parse(txtField2.Text));
                        currentBooking.setFlightId(int.Parse(txtField3.Text));
                        currentBooking.setConnectingFlightId(int.Parse(txtField4.Text));
                        currentBooking.setBookingType(txtField5.Text);
                        break;
                }

                MessageBox.Show("Changes saved successfully!");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving changes: {ex.Message}");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstAuditTrail_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
