using System;
using System.IO;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Login : Form
    {
        private UserList userList;
        private FlightList flightList;
        private BookingList bookingList;
        public Login()
        {
            userList = new UserList();
            flightList = new FlightList();
            bookingList = new BookingList();
            LoadData();
            InitializeComponent();

            this.FormClosed += new FormClosedEventHandler(Login_FormClosed);
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            bookingList.updateBookingData("Booking.txt");
            flightList.updateFlightData("Flight.txt");
            userList.updateUserData("User.txt");
        }

        // Event handler triggered when the form loads

        private void LoadData()
        {
            try
            {
                userList.loadUserList("User.txt");
                flightList.loadFlightList("Flight.txt");
                bookingList.loadBookingList("Booking.txt");
                MessageBox.Show("Data loaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File not found: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            // Initialize settings when the form loads (add if needed)
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Code to handle label click can be added here
            // This can be left empty or modified as needed
        }

        // Event handler triggered when the login button is clicked
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;  // Input for username
            string password = txtPassword.Text;  // Input for password

            if (userList.hasUser(username, password))  // Verify login credentials
            {
                lblMessage.Text = "Login Successful!";  // Display login success message
                lblMessage.ForeColor = System.Drawing.Color.Green;  // Display success message in green

                // Navigate to the Home form if login is successful
                User userCookies = userList.getUser(username, password);
                string userRole = userCookies.getRole();
                if (userCookies != null && userRole == "user")
                {
                    Home homeForm = new Home(userCookies ,userList, flightList, bookingList);
                    homeForm.Show();  // Show the Home form
                    this.Hide();  // Hide the current Login form
                    homeForm.FormClosed += (s, args) => this.Show();// Reopen Login form is Home closed
                }
                else if(userCookies != null && userRole == "admin")
                {
                    AdminHome adminHomeForm = new AdminHome(userList, flightList, bookingList);
                    adminHomeForm.Show();
                    this.Hide();
                    adminHomeForm.FormClosed += (s, args) => this.Show();
                }
            }
            else
            {
                lblMessage.Text = "Login failed.";  // Display login failure message
                lblMessage.ForeColor = System.Drawing.Color.Red;  // Display failure message in red
            }
        }

        // Open the signup form (navigate to Register form)
        private void btnSignup_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm(this);  // Create Register form
            registerForm.Show();  // Show the Register form
            this.Hide();  // Hide the current Login form
            registerForm.FormClosed += (s, args) => this.Show();
        }
    }
}