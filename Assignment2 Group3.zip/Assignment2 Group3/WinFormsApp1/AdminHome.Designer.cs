﻿namespace WinFormsApp1
{
    partial class AdminHome
    {
        private System.ComponentModel.IContainer components = null;

        // ListBoxes for users, flights, and bookings
        private System.Windows.Forms.ListBox listBoxUsers;
        private System.Windows.Forms.ListBox listBoxFlights;
        private System.Windows.Forms.ListBox listBoxBookings;

        // Buttons
        private System.Windows.Forms.Button btnListUsers;
        private System.Windows.Forms.Button btnDeleteUser;
        private System.Windows.Forms.Button btnEditUser;

        private System.Windows.Forms.Button btnListFlights;
        private System.Windows.Forms.Button btnDeleteFlight;
        private System.Windows.Forms.Button btnEditFlight;

        private System.Windows.Forms.Button btnListBookings;
        private System.Windows.Forms.Button btnDeleteBooking;
        private System.Windows.Forms.Button btnEditBooking;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            listBoxUsers = new ListBox();
            listBoxFlights = new ListBox();
            listBoxBookings = new ListBox();
            btnListUsers = new Button();
            btnDeleteUser = new Button();
            btnEditUser = new Button();
            btnListFlights = new Button();
            btnDeleteFlight = new Button();
            btnEditFlight = new Button();
            btnListBookings = new Button();
            btnDeleteBooking = new Button();
            btnEditBooking = new Button();
            SuspendLayout();
            // 
            // listBoxUsers
            // 
            listBoxUsers.ItemHeight = 25;
            listBoxUsers.Location = new Point(12, 12);
            listBoxUsers.Name = "listBoxUsers";
            listBoxUsers.Size = new Size(576, 79);
            listBoxUsers.TabIndex = 0;
            // 
            // listBoxFlights
            // 
            listBoxFlights.ItemHeight = 25;
            listBoxFlights.Location = new Point(12, 130);
            listBoxFlights.Name = "listBoxFlights";
            listBoxFlights.Size = new Size(576, 79);
            listBoxFlights.TabIndex = 1;
            // 
            // listBoxBookings
            // 
            listBoxBookings.ItemHeight = 25;
            listBoxBookings.Location = new Point(12, 250);
            listBoxBookings.Name = "listBoxBookings";
            listBoxBookings.Size = new Size(576, 79);
            listBoxBookings.TabIndex = 2;
            // 
            // btnListUsers
            // 
            btnListUsers.Location = new Point(657, 41);
            btnListUsers.Name = "btnListUsers";
            btnListUsers.Size = new Size(100, 30);
            btnListUsers.TabIndex = 3;
            btnListUsers.Text = "List Users";
            btnListUsers.Click += btnListUsers_Click;
            // 
            // btnDeleteUser
            // 
            btnDeleteUser.Location = new Point(877, 41);
            btnDeleteUser.Name = "btnDeleteUser";
            btnDeleteUser.Size = new Size(100, 30);
            btnDeleteUser.TabIndex = 5;
            btnDeleteUser.Text = "Delete User";
            btnDeleteUser.Click += btnDeleteUser_Click;
            // 
            // btnEditUser
            // 
            btnEditUser.Location = new Point(767, 41);
            btnEditUser.Name = "btnEditUser";
            btnEditUser.Size = new Size(100, 30);
            btnEditUser.TabIndex = 4;
            btnEditUser.Text = "Edit User";
            btnEditUser.Click += btnEditUser_Click;
            // 
            // btnListFlights
            // 
            btnListFlights.Location = new Point(657, 159);
            btnListFlights.Name = "btnListFlights";
            btnListFlights.Size = new Size(100, 30);
            btnListFlights.TabIndex = 6;
            btnListFlights.Text = "List Flights";
            btnListFlights.Click += btnListFlights_Click;
            // 
            // btnDeleteFlight
            // 
            btnDeleteFlight.Location = new Point(877, 159);
            btnDeleteFlight.Name = "btnDeleteFlight";
            btnDeleteFlight.Size = new Size(100, 30);
            btnDeleteFlight.TabIndex = 8;
            btnDeleteFlight.Text = "Delete Flight";
            btnDeleteFlight.Click += btnDeleteFlight_Click;
            // 
            // btnEditFlight
            // 
            btnEditFlight.Location = new Point(767, 159);
            btnEditFlight.Name = "btnEditFlight";
            btnEditFlight.Size = new Size(100, 30);
            btnEditFlight.TabIndex = 7;
            btnEditFlight.Text = "Edit Flight";
            btnEditFlight.Click += btnEditFlight_Click;
            // 
            // btnListBookings
            // 
            btnListBookings.Location = new Point(657, 279);
            btnListBookings.Name = "btnListBookings";
            btnListBookings.Size = new Size(100, 30);
            btnListBookings.TabIndex = 9;
            btnListBookings.Text = "List Bookings";
            btnListBookings.Click += btnListBookings_Click;
            // 
            // btnDeleteBooking
            // 
            btnDeleteBooking.Location = new Point(877, 279);
            btnDeleteBooking.Name = "btnDeleteBooking";
            btnDeleteBooking.Size = new Size(100, 30);
            btnDeleteBooking.TabIndex = 11;
            btnDeleteBooking.Text = "Delete Booking";
            btnDeleteBooking.Click += btnDeleteBooking_Click;
            // 
            // btnEditBooking
            // 
            btnEditBooking.Location = new Point(767, 279);
            btnEditBooking.Name = "btnEditBooking";
            btnEditBooking.Size = new Size(100, 30);
            btnEditBooking.TabIndex = 10;
            btnEditBooking.Text = "Edit Booking";
            btnEditBooking.Click += btnEditBooking_Click;
            // 
            // AdminHome
            // 
            ClientSize = new Size(1085, 400);
            Controls.Add(listBoxUsers);
            Controls.Add(listBoxFlights);
            Controls.Add(listBoxBookings);
            Controls.Add(btnListUsers);
            Controls.Add(btnEditUser);
            Controls.Add(btnDeleteUser);
            Controls.Add(btnListFlights);
            Controls.Add(btnEditFlight);
            Controls.Add(btnDeleteFlight);
            Controls.Add(btnListBookings);
            Controls.Add(btnEditBooking);
            Controls.Add(btnDeleteBooking);
            Name = "AdminHome";
            Text = "Admin Home";
            Load += AdminHome_Load;
            ResumeLayout(false);
        }
    }
}