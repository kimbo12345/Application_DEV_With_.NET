﻿namespace WinFormsApp1
{
    partial class EditForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtField1;
        private System.Windows.Forms.TextBox txtField2;
        private System.Windows.Forms.TextBox txtField3;
        private System.Windows.Forms.TextBox txtField4;
        private System.Windows.Forms.TextBox txtField5;
        private System.Windows.Forms.Label lblField1;
        private System.Windows.Forms.Label lblField2;
        private System.Windows.Forms.Label lblField3;
        private System.Windows.Forms.Label lblField4;
        private System.Windows.Forms.Label lblField5;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ListBox lstAuditTrail; // ListBox for the audit trail

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtField1 = new TextBox();
            txtField2 = new TextBox();
            txtField3 = new TextBox();
            txtField4 = new TextBox();
            txtField5 = new TextBox();
            lblField1 = new Label();
            lblField2 = new Label();
            lblField3 = new Label();
            lblField4 = new Label();
            lblField5 = new Label();
            btnSave = new Button();
            btnCancel = new Button();
            lstAuditTrail = new ListBox();
            SuspendLayout();
            // 
            // txtField1
            // 
            txtField1.Location = new Point(56, 20);
            txtField1.Name = "txtField1";
            txtField1.Size = new Size(164, 31);
            txtField1.TabIndex = 0;
            // 
            // txtField2
            // 
            txtField2.Location = new Point(56, 60);
            txtField2.Name = "txtField2";
            txtField2.Size = new Size(164, 31);
            txtField2.TabIndex = 1;
            // 
            // txtField3
            // 
            txtField3.Location = new Point(56, 100);
            txtField3.Name = "txtField3";
            txtField3.Size = new Size(164, 31);
            txtField3.TabIndex = 2;
            // 
            // txtField4
            // 
            txtField4.Location = new Point(56, 140);
            txtField4.Name = "txtField4";
            txtField4.Size = new Size(164, 31);
            txtField4.TabIndex = 3;
            // 
            // txtField5
            // 
            txtField5.Location = new Point(56, 180);
            txtField5.Name = "txtField5";
            txtField5.Size = new Size(164, 31);
            txtField5.TabIndex = 4;
            // 
            // lblField1
            // 
            lblField1.Location = new Point(20, 20);
            lblField1.Name = "lblField1";
            lblField1.Size = new Size(100, 23);
            lblField1.TabIndex = 5;
            // 
            // lblField2
            // 
            lblField2.Location = new Point(20, 60);
            lblField2.Name = "lblField2";
            lblField2.Size = new Size(100, 23);
            lblField2.TabIndex = 6;
            // 
            // lblField3
            // 
            lblField3.Location = new Point(20, 100);
            lblField3.Name = "lblField3";
            lblField3.Size = new Size(100, 23);
            lblField3.TabIndex = 7;
            // 
            // lblField4
            // 
            lblField4.Location = new Point(20, 140);
            lblField4.Name = "lblField4";
            lblField4.Size = new Size(100, 23);
            lblField4.TabIndex = 8;
            // 
            // lblField5
            // 
            lblField5.Location = new Point(20, 180);
            lblField5.Name = "lblField5";
            lblField5.Size = new Size(100, 23);
            lblField5.TabIndex = 9;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(66, 220);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 44);
            btnSave.TabIndex = 10;
            btnSave.Text = "Save";
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(147, 220);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 44);
            btnCancel.TabIndex = 11;
            btnCancel.Text = "Cancel";
            btnCancel.Click += btnCancel_Click;
            // 
            // lstAuditTrail
            // 
            lstAuditTrail.FormattingEnabled = true;
            lstAuditTrail.ItemHeight = 25;
            lstAuditTrail.Location = new Point(299, 20);
            lstAuditTrail.Name = "lstAuditTrail";
            lstAuditTrail.Size = new Size(305, 179);
            lstAuditTrail.TabIndex = 12;
            lstAuditTrail.SelectedIndexChanged += lstAuditTrail_SelectedIndexChanged;
            // 
            // EditForm
            // 
            ClientSize = new Size(682, 327);
            Controls.Add(txtField1);
            Controls.Add(txtField2);
            Controls.Add(txtField3);
            Controls.Add(txtField4);
            Controls.Add(txtField5);
            Controls.Add(lblField1);
            Controls.Add(lblField2);
            Controls.Add(lblField3);
            Controls.Add(lblField4);
            Controls.Add(lblField5);
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            Controls.Add(lstAuditTrail);
            Name = "EditForm";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}

