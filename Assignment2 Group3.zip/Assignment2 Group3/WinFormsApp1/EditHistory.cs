﻿using System;

namespace WinFormsApp1
{
    public class EditHistory
    {
        public int Id { get; set; }
        public string FieldName { get; set; } // 변경된 필드 이름
        public string OldValue { get; set; }  // 이전 값
        public string NewValue { get; set; }  // 새로운 값
        public DateTime Timestamp { get; set; } // 변경 시간

        public override string ToString()
        {
            return $"{Timestamp}: {FieldName} changed from '{OldValue}' to '{NewValue}'";
        }
    }
}

