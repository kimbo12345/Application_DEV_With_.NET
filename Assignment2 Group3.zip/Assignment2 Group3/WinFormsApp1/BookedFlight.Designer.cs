﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    partial class BookedFlight
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private Button closeButton;
        private Label label1;
        private DataGridView dataGridViewBooking;

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            label1 = new Label();
            closeButton = new Button();
            dataGridViewBooking = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBooking).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Arial", 16F, FontStyle.Bold);
            label1.Location = new Point(386, 9);
            label1.Name = "label1";
            label1.Size = new Size(267, 48);
            label1.TabIndex = 0;
            label1.Text = "Booked Flights";
            // 
            // closeButton
            // 
            closeButton.Location = new Point(420, 363);
            closeButton.Name = "closeButton";
            closeButton.Size = new Size(159, 51);
            closeButton.TabIndex = 1;
            closeButton.Text = "Close";
            closeButton.Click += CloseButton_Click;
            // 
            // dataGridViewBooking
            // 
            dataGridViewBooking.ColumnHeadersHeight = 34;
            dataGridViewBooking.Location = new Point(39, 69);
            dataGridViewBooking.Name = "dataGridViewBooking";
            dataGridViewBooking.RowHeadersWidth = 62;
            dataGridViewBooking.Size = new Size(942, 258);
            dataGridViewBooking.TabIndex = 2;
            // 
            // BookedFlight
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1006, 460);
            Controls.Add(label1);
            Controls.Add(closeButton);
            Controls.Add(dataGridViewBooking);
            Margin = new Padding(4, 5, 4, 5);
            Name = "BookedFlight";
            Text = "Home";
            Load += Home_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewBooking).EndInit();
            ResumeLayout(false);
        }
        #endregion
        private void CloseButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void InitializeDataGridView()
        {
            dataGridViewBooking.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            // Add columns for flight data
            dataGridViewBooking.Columns.Add("BookingId", "Booking ID");
            dataGridViewBooking.Columns.Add("FlightId", "Flight ID");
            dataGridViewBooking.Columns.Add("ConnectingFlightId", "Connecting Flight ID");
            dataGridViewBooking.Columns.Add("BookingType", "Booking Type");
            // Add a Button Column for adding flights
            DataGridViewButtonColumn removeButtonColumn = new DataGridViewButtonColumn();
            removeButtonColumn.Name = "RemoveFlight";
            removeButtonColumn.HeaderText = "Remove Flight";
            removeButtonColumn.Text = "Remove";
            removeButtonColumn.UseColumnTextForButtonValue = true;
            dataGridViewBooking.Columns.Add(removeButtonColumn);
        }
    }
}
