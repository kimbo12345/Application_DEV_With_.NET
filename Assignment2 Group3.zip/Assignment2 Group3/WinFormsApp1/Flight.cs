﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace WinFormsApp1
{
    public class Flight
    {
        private int id {  get; set; }
        private string flightName { get; set; }
        private string airline {  get; set; }
        private string arrival { get; set; }
        private string destination { get; set; }

        public Flight() { }

        public Flight(int id, string flightName, string airline, string arrival, string destination)
        {
            this.id = id;
            this.flightName = flightName;
            this.airline = airline;
            this.arrival = arrival;
            this.destination = destination;
        }
        //Functions
        public void loadFlight(string dataLine)
        {
            string[] tempFlight = dataLine.Split('|');
            this.id = Convert.ToInt32(tempFlight[0]);
            this.flightName = tempFlight[1];
            this.airline = tempFlight[2];
            this.arrival = tempFlight[3];
            this.destination = tempFlight[4];
        }

        //Getter and Setter
        public int getId()
        {
            return this.id;
        }
        public void setId(int id)
        {
            this.id = id;
        }
        public string getFlightName()
        {
            return this.flightName;
        }
        public void setFlightName(string flightName)
        {
            this.flightName = flightName;
        }
        public string getAirline()
        {
            return this.airline;
        }
        public void setAirline(string airline)
        {
            this.airline = airline;
        }
        public string getArrival()
        {
            return this.arrival;
        }
        public void setArrival(string arrival)
        {
            this.arrival = arrival;
        }
        public string getDestination()
        {
            return this.destination;
        }
        public void setDestination(string destination)
        {
            this.destination = destination;
        }
    }
}
*/



namespace WinFormsApp1
{
    public class Flight
    {
        private int id { get; set; }
        private string flightName { get; set; }
        private string airline { get; set; }
        private string arrival { get; set; }
        private string destination { get; set; }
        private List<string> editHistory; // To store change logs

        public Flight()
        {
            editHistory = new List<string>();
        }

        public Flight(int id, string flightName, string airline, string arrival, string destination)
        {
            this.id = id;
            this.flightName = flightName;
            this.airline = airline;
            this.arrival = arrival;
            this.destination = destination;
            editHistory = new List<string>();
        }

        public void loadFlight(string dataLine)
        {
            string[] tempFlight = dataLine.Split('|');
            this.id = Convert.ToInt32(tempFlight[0]);
            this.flightName = tempFlight[1];
            this.airline = tempFlight[2];
            this.arrival = tempFlight[3];
            this.destination = tempFlight[4];
        }

        public void LogEdit(string change)
        {
            editHistory.Add($"{DateTime.Now}: {change}");
        }

        public List<string> GetEditHistory() => editHistory;

        // Getters and Setters with audit logging
        public int getId() => this.id;
        public void setId(int id) { LogEdit($"Id changed from {this.id} to {id}"); this.id = id; }

        public string getFlightName() => this.flightName;
        public void setFlightName(string flightName) { LogEdit($"FlightName changed from {this.flightName} to {flightName}"); this.flightName = flightName; }

        public string getAirline() => this.airline;
        public void setAirline(string airline) { LogEdit($"Airline changed from {this.airline} to {airline}"); this.airline = airline; }

        public string getArrival() => this.arrival;
        public void setArrival(string arrival) { LogEdit($"Arrival changed from {this.arrival} to {arrival}"); this.arrival = arrival; }

        public string getDestination() => this.destination;
        public void setDestination(string destination) { LogEdit($"Destination changed from {this.destination} to {destination}"); this.destination = destination; }
    }
}
