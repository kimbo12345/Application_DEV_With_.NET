﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace WinFormsApp1
{
    public class Booking
    {
        private int id;
        private int userId;
        private int flightId;
        private int connectingFlightId;
        private string bookingType;
        public Booking() {
        }

        public Booking(int id, int userId, int flightId, int connectingFlightId, string bookingType)
        {
            this.id = id;
            this.userId = userId;
            this.flightId = flightId;
            this.connectingFlightId = connectingFlightId;
            this.bookingType = bookingType;
        }
        //Functions
        public void loadBooking(string dataLine)
        {
            if (!string.IsNullOrEmpty(dataLine))
            {
                string[] tempUser = dataLine.Split('|');
                this.id = Convert.ToInt32(tempUser[0]);
                this.userId = Convert.ToInt32(tempUser[1]);
                this.flightId = Convert.ToInt32(tempUser[2]);
                this.connectingFlightId = Convert.ToInt32(tempUser[3]);
                this.bookingType = tempUser[4];
            }
        }

        //Getter and Setter
        public int getId()
        {
            return id;
        }
        public void setId(int id)
        {
            this.id = id;
        }
        public int getUserId()
        {
            return userId;
        }
        public void setUserId(int userId)
        {
            this.userId = userId;
        }
        public int getFlightId()
        {
            return flightId;
        }
        public void setFlightId(int flightId)
        {
            this.flightId = flightId;
        }
        public int getConnectingFlightId()
        {
            return connectingFlightId;
        }
        public void setConnectingFlightId(int connectingFlightId)
        {
            this.connectingFlightId=connectingFlightId;
        }
        public string getBookingType()
        {
            return bookingType;
        }
        public void setBookingType(string bookingType)
        {
            this.bookingType = bookingType;
        }
    }
}
*/



namespace WinFormsApp1
{
    public class Booking
    {
        private int id;
        private int userId;
        private int flightId;
        private int connectingFlightId;
        private string bookingType;
        private List<string> editHistory; // To store change logs

        public Booking()
        {
            editHistory = new List<string>();
        }

        public Booking(int id, int userId, int flightId, int connectingFlightId, string bookingType)
        {
            this.id = id;
            this.userId = userId;
            this.flightId = flightId;
            this.connectingFlightId = connectingFlightId;
            this.bookingType = bookingType;
            editHistory = new List<string>();
        }

        public void loadBooking(string dataLine)
        {
            if (!string.IsNullOrEmpty(dataLine))
            {
                string[] tempUser = dataLine.Split('|');
                this.id = Convert.ToInt32(tempUser[0]);
                this.userId = Convert.ToInt32(tempUser[1]);
                this.flightId = Convert.ToInt32(tempUser[2]);
                this.connectingFlightId = Convert.ToInt32(tempUser[3]);
                this.bookingType = tempUser[4];
            }
        }

        public void LogEdit(string change)
        {
            editHistory.Add($"{DateTime.Now}: {change}");
        }

        public List<string> GetEditHistory() => editHistory;

        // Getters and Setters with audit logging
        public int getId() => this.id;
        public void setId(int id) { LogEdit($"Id changed from {this.id} to {id}"); this.id = id; }

        public int getUserId() => this.userId;
        public void setUserId(int userId) { LogEdit($"UserId changed from {this.userId} to {userId}"); this.userId = userId; }

        public int getFlightId() => this.flightId;
        public void setFlightId(int flightId) { LogEdit($"FlightId changed from {this.flightId} to {flightId}"); this.flightId = flightId; }

        public int getConnectingFlightId() => this.connectingFlightId;
        public void setConnectingFlightId(int connectingFlightId) { LogEdit($"ConnectingFlightId changed from {this.connectingFlightId} to {connectingFlightId}"); this.connectingFlightId = connectingFlightId; }

        public string getBookingType() => this.bookingType;
        public void setBookingType(string bookingType) { LogEdit($"BookingType changed from {this.bookingType} to {bookingType}"); this.bookingType = bookingType; }
    }
}
