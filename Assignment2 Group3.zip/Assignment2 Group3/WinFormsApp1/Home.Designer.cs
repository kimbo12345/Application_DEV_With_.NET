﻿namespace WinFormsApp1
{
    partial class Home
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label1 = new Label();
            dataGridViewFlights = new DataGridView();
            dataGridViewConnectingFlight = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewFlights).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewConnectingFlight).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(680, 146);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(129, 38);
            button1.TabIndex = 0;
            button1.Text = "Filter Flight";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(356, 87);
            button2.Margin = new Padding(4, 5, 4, 5);
            button2.Name = "button2";
            button2.Size = new Size(217, 38);
            button2.TabIndex = 5;
            button2.Text = "Show Booked Flights";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(581, 87);
            button3.Margin = new Padding(4, 5, 4, 5);
            button3.Name = "button3";
            button3.Size = new Size(178, 38);
            button3.TabIndex = 6;
            button3.Text = "Find Flights";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(136, 150);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Arrival";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 1;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(311, 150);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Destination";
            textBox2.Size = new Size(150, 31);
            textBox2.TabIndex = 4;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(487, 150);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Airline";
            textBox3.Size = new Size(150, 31);
            textBox3.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaption;
            label1.Font = new Font("Malgun Gothic", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            label1.Location = new Point(525, 9);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(137, 55);
            label1.TabIndex = 2;
            label1.Text = "Home";
            // 
            // dataGridViewFlights
            // 
            dataGridViewFlights.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewFlights.Location = new Point(136, 204);
            dataGridViewFlights.Margin = new Padding(4, 5, 4, 5);
            dataGridViewFlights.Name = "dataGridViewFlights";
            dataGridViewFlights.RowHeadersWidth = 62;
            dataGridViewFlights.Size = new Size(904, 253);
            dataGridViewFlights.TabIndex = 3;
            //dataGridViewFlights.CellContentClick += dataGridViewFlights_CellContentClick;
            // 
            // dataGridViewConnectingFlight
            // 
            dataGridViewConnectingFlight.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewConnectingFlight.Location = new Point(136, 487);
            dataGridViewConnectingFlight.Margin = new Padding(4, 5, 4, 5);
            dataGridViewConnectingFlight.Name = "dataGridViewConnectingFlight";
            dataGridViewConnectingFlight.RowHeadersWidth = 62;
            dataGridViewConnectingFlight.Size = new Size(904, 228);
            dataGridViewConnectingFlight.TabIndex = 8;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1180, 959);
            Controls.Add(dataGridViewConnectingFlight);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(textBox1);
            Controls.Add(textBox2);
            Controls.Add(textBox3);
            Controls.Add(button1);
            Controls.Add(dataGridViewFlights);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Home";
            Text = "Home";
            Load += Home_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewFlights).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewConnectingFlight).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Label label1;
        private DataGridView dataGridViewFlights;
        private DataGridView dataGridViewConnectingFlight;

        private void InitializeDataGridView()
        {
            dataGridViewFlights.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewFlights.AllowUserToAddRows = false;

            // Add columns for flight data
            dataGridViewFlights.Columns.Add("FlightId", "Flight ID");
            dataGridViewFlights.Columns.Add("FlightName", "Flight Name");
            dataGridViewFlights.Columns.Add("Airline", "Airline");
            dataGridViewFlights.Columns.Add("Arrival", "Arrival");
            dataGridViewFlights.Columns.Add("Destination", "Destination");

            // Add a Button Column for adding flights
            DataGridViewButtonColumn addButtonColumn = new DataGridViewButtonColumn();
            addButtonColumn.Name = "AddFlight";
            addButtonColumn.HeaderText = "Add Flight";
            addButtonColumn.Text = "Add";
            addButtonColumn.UseColumnTextForButtonValue = true;
            dataGridViewFlights.Columns.Add(addButtonColumn);
        }

        private void InitializeDataGridViewConnectingFlight()
        {
            dataGridViewConnectingFlight.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewConnectingFlight.AllowUserToAddRows= false;
            // Add columns for connecting flight data
            dataGridViewConnectingFlight.AllowUserToAddRows = false;
            dataGridViewConnectingFlight.Columns.Add("Trip", "Trip");
            dataGridViewConnectingFlight.Columns.Add("FirstFlightId", "First Flight ID");
            dataGridViewConnectingFlight.Columns.Add("FirstFlightName", "First Flight Name");
            dataGridViewConnectingFlight.Columns.Add("NextFlightId", "Next Flight ID");
            dataGridViewConnectingFlight.Columns.Add("NextFlightName", "Next Flight Name");

            // Add a Button Column for adding connecting flights
            DataGridViewButtonColumn addButtonColumn = new DataGridViewButtonColumn();
            addButtonColumn.Name = "AddConnectingFlight";
            addButtonColumn.HeaderText = "Add Connecting Flight";
            addButtonColumn.Text = "Add";
            addButtonColumn.UseColumnTextForButtonValue = true;
            dataGridViewConnectingFlight.Columns.Add(addButtonColumn);
        }

       
    }
}
