﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    partial class BookedFlight : Form
    {
        private User userCookies;
        private FlightList flightList;
        private BookingList bookingList;
        public BookedFlight(User userCookies, FlightList flightList, BookingList bookingList)
        {
            this.userCookies = userCookies;
            this.flightList = flightList;
            this.bookingList = bookingList;
            InitializeComponent();
            InitializeDataGridView();
            dataGridViewBooking.CellContentClick += dataGridViewBooking_RemoveBooking;

        }

        private void Home_Load(object sender, EventArgs e)
        {
            displayBooking();
        }

        private void displayBooking()
        {
            dataGridViewBooking.Rows.Clear();

            List<Booking> bookings = bookingList.getBookingList(userCookies.getId());
            foreach (Booking booking in bookings)
            {
                int rowIndex = dataGridViewBooking.Rows.Add(
                    booking.getId(),
                    booking.getFlightId(),
                    booking.getConnectingFlightId(),
                    booking.getBookingType()
                );
                dataGridViewBooking.Rows[rowIndex].Tag = booking;
            }
        }

        private void dataGridViewBooking_RemoveBooking(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            //Check if sender is from DataGridButtonColumn
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn
                && e.RowIndex >= 0)
            {
                Booking selectedBooking = (Booking)dataGridViewBooking.Rows[e.RowIndex].Tag;
                if (selectedBooking != null)
                {
                    try
                    {
                        bookingList.removeBooking(selectedBooking);
                        MessageBox.Show("Remove Booking Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        displayBooking();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error removing booking: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

    }
}
