﻿namespace WinFormsApp1
{
    public class UserList
    {
        private ObjList<User> userList;

        public UserList()
        {
            userList = new ObjList<User>();
        }

        public bool hasUser(string username, string password)
        {
            return userList.getItems().Any(tempUser => tempUser.isUsername(username) && tempUser.isPassword(password));
        }

        public User getUser(string username, string password)
        {
            try
            {
                return userList.getItems().FirstOrDefault(tempUser => tempUser.isUsername(username) && tempUser.isPassword(password));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot get user", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        public User getUserByUserId(int id)
        {
            return userList.getItems().FirstOrDefault(u => u.getId() == id);
        }

        public void addUser(User user)
        {
            userList.addItem(user);
        }

        public void removeUserById(int id)
        {
            User selectedUser = userList.getItems().FirstOrDefault(tempUser => tempUser.getId() == id);
            if (selectedUser != null)
            {
                userList.removeItem(selectedUser);
            }
        }

        public void removeUser(User user)
        {
            userList.removeItem(user);
        }

        public void loadUserList(string fileName)
        {
            userList.loadItems(fileName, (user, line) => user.loadUser(line));
        }
        public List<User> getUserList()
        {
            return userList.getItems();
        }

        public List<int> getUserIdList()
        {
            return userList.getItems().Select(tempUser => tempUser.getId()).ToList();
        }

        public void updateUserData(string fileName)
        {
            try
            {
                using StreamWriter writer = new StreamWriter(fileName, false);
                foreach (User user in userList.getItems())
                {
                    string userId = Convert.ToString(user.getId());
                    writer.WriteLine($"{userId}|{user.getName()}|{user.getUsername()}|{user.getPassword()}|{user.getRole()}");
                }
            }
            catch (FileNotFoundException ex)
            {
            }
            catch (Exception ex)
            {
            }
        }
    }
}