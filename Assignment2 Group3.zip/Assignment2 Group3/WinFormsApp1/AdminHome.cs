﻿using System;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class AdminHome : Form
    {
        private UserList userList;
        private FlightList flightList;
        private BookingList bookingList;

        public AdminHome(UserList users, FlightList flights, BookingList bookings)
        {
            InitializeComponent();
            userList = users;
            flightList = flights;
            bookingList = bookings;
        }

        private void btnListUsers_Click(object sender, EventArgs e)
        {
            listBoxUsers.Items.Clear();  // First clear the list.

            foreach (var user in userList.getUserList())
            {
                // Add each user's information in the format "ID - Name - Password - Role"
                string userInfo = $"{user.getId()} - {user.getUsername()} - {user.getPassword()} - {user.getRole()}";
                listBoxUsers.Items.Add(userInfo);
            }
        }

        private void btnEditUser_Click(object sender, EventArgs e)
        {
            if (listBoxUsers.SelectedItem != null)
            {
                var selectedUser = listBoxUsers.SelectedItem.ToString();
                var userId = int.Parse(selectedUser.Split(' ')[0]);
                var currentUser = userList.getUserList().FirstOrDefault(u => u.getId() == userId);

                if (currentUser != null)
                {
                    EditForm editForm = new EditForm(currentUser);
                    editForm.ShowDialog();
                }
            }
        }


        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            if (listBoxUsers.SelectedItem != null)
            {
                var selectedUser = listBoxUsers.SelectedItem.ToString();
                var userId = int.Parse(selectedUser.Split(' ')[0]);
                userList.removeUserById(userId);
                bookingList.triggerRemoveAllBookingWithUserId(userId);
                btnListBookings_Click(sender, e);
                btnListUsers_Click(sender, e);  // Refresh the list
            }
        }

        private void btnListFlights_Click(object sender, EventArgs e)
        {
            listBoxFlights.Items.Clear();
            foreach (var flight in flightList.getFlightList())
            {
                listBoxFlights.Items.Add($"{flight.getId()} - {flight.getFlightName()} - {flight.getAirline()} - {flight.getArrival()} - {flight.getDestination()}");
            }
        }

        private void btnEditFlight_Click(object sender, EventArgs e)
        {
            if (listBoxFlights.SelectedItem != null)
            {
                var selectedFlight = listBoxFlights.SelectedItem.ToString();
                var flightId = int.Parse(selectedFlight.Split(' ')[0]);
                var currentFlight = flightList.getFlightById(flightId);

                EditForm editForm = new EditForm(currentFlight);
                editForm.ShowDialog();
                btnListFlights_Click(sender, e);
            }
        }

        private void btnDeleteFlight_Click(object sender, EventArgs e)
        {
            if (listBoxFlights.SelectedItem != null)
            {
                var selectedFlight = listBoxFlights.SelectedItem.ToString();
                // Flight ID is now handled as a string.
                var flightId = Convert.ToInt32(selectedFlight.Split(' ')[0]);
                flightList.removeFlightById(flightId);  // Handle RemoveFlightById with string argument
                bookingList.triggerRemoveAllBookingWithFlightId(flightId); //trigger delete all booking with said flight Id including connecting flights

                btnListBookings_Click(sender, e); //Refresh booking list display
                btnListFlights_Click(sender, e);  // Refresh flight list display
            }
        }

        private void btnListBookings_Click(object sender, EventArgs e)
        {
            listBoxBookings.Items.Clear(); //Clear the initial list display
            foreach (var booking in bookingList.getBookingList())
            {
                var connectingFlightId = "";
                var user = userList.getUserByUserId(booking.getUserId());
                var flight = flightList.getFlightById(booking.getFlightId());
                var connectingFlight = booking.getConnectingFlightId() > 0
                                       ? flightList.getFlightById(booking.getConnectingFlightId())
                                       : null;

                string connectingFlightInfo = "null";
                if (user != null && flight != null)
                {
                    if (connectingFlight != null)
                    {
                        connectingFlightInfo = $"{booking.getConnectingFlightId()} - {connectingFlight.getFlightName()}";
                    }
                    listBoxBookings.Items.Add($"{booking.getId()} - {booking.getUserId()} - {user.getUsername()} - {booking.getFlightId()} - {flight.getFlightName()} - {connectingFlightInfo} - {booking.getBookingType()}");
                }
                else
                {
                    listBoxBookings.Items.Add($"Booking ID: {booking.getId()} - Error: User or Flight data is null.");
                }
            }
        }

        private void btnEditBooking_Click(object sender, EventArgs e)
        {
            if (listBoxBookings.SelectedItem != null)
            {
                var selectedBooking = listBoxBookings.SelectedItem.ToString();
                var bookingId = int.Parse(selectedBooking.Split(' ')[0]);
                var currentBooking = bookingList.getBookingById(bookingId);

                EditForm editForm = new EditForm(currentBooking);
                editForm.ShowDialog();

                btnListBookings_Click(sender, e);  //Refresh booking list display

            }
        }

        private void btnDeleteBooking_Click(object sender, EventArgs e)
        {
            if (listBoxBookings.SelectedItem != null)
            {
                var selectedBooking = listBoxBookings.SelectedItem.ToString();
                var bookingId = int.Parse(selectedBooking.Split(' ')[0]);
                bookingList.removeBookingById(bookingId);
                btnListBookings_Click(sender, e);  // Refresh the list
            }
        }

        private void AdminHome_Load(object sender, EventArgs e)
        {

        }
    }
}
