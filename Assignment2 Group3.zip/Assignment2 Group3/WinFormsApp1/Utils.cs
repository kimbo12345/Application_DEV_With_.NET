﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public class Utils
    {
        public Utils() { }

        public int GenerateNewRandomID(List<int> list)
        {
            Random random = new Random();
            int newId = random.Next(1, 100000);
            do
            {
                newId = random.Next(1, 1000000);
            }
            while(
                list.Contains(newId)
            );

            return newId;
        }

        public string GenerateNewFlightName(List<string> flightNameList)
        {

            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            char[] stringChars = new char[6];
            Random random = new Random();
            do
            {
                Random r = new Random();
                int randomIdLength = r.Next(4, 6);
                for (int i = 0; i < randomIdLength; i++)
                {
                    stringChars[i] = chars[random.Next(chars.Length)];
                }
            }
            while (flightNameList.Contains(new string(stringChars)));
            return new string(stringChars);
        }
    }
}
