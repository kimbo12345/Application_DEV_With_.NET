﻿namespace WinFormsApp1
{
    public class FlightList
    {
        private ObjList<Flight> flightList;
        public FlightList()
        {
            flightList = new ObjList<Flight>();
        }
        public void loadFlightList(string fileName)
        {
            flightList.loadItems(fileName, (flight, line) => flight.loadFlight(line));
        }
        public List<Flight> getFlightList()
        {
            return flightList.getItems();
        }
        public Flight getFlightById(int flightId)
        {
            // flightList에서 해당 ID를 가진 Flight를 찾아 반환합니다.
            return flightList.getItems().FirstOrDefault(flight => flight.getId() == flightId);
        }

        public void addFlight(Flight flight)
        {
            flightList.addItem(flight);
        }
        public void removeFlight(Flight flight)
        {
            flightList.removeItem(flight);
        }
        public void removeFlightById(int id)
        {
            Flight selectedFlight = flightList.getItems().FirstOrDefault(tempFlight => tempFlight.getId() == id);
            if (selectedFlight != null)
            {
                flightList.removeItem(selectedFlight);
            }
        }
        public List<Flight> getFlightFromFilter(string arrivalFilter, string destinationFilter, string airlineFilter)
        {
            //Change all filter keyword to lower case
            arrivalFilter = arrivalFilter?.ToLower();
            destinationFilter = destinationFilter?.ToLower();
            airlineFilter = airlineFilter?.ToLower();
            //Lambda: return a list of Flight
            return flightList.getItems().Where(flight =>
                (string.IsNullOrEmpty(arrivalFilter) || flight.getArrival().ToLower().Contains(arrivalFilter)) &&
                (string.IsNullOrEmpty(destinationFilter) || flight.getDestination().ToLower().Contains(destinationFilter)) &&
                (string.IsNullOrEmpty(airlineFilter) || flight.getAirline().ToLower().Contains(airlineFilter))
            ).ToList();
        }

        public List<Tuple<Flight, Flight>> getConnectingFlightListFromFilter(string arrivalFilter, string destinationFilter, string airlineFilter)
        {
            List<Tuple<Flight, Flight>> connectingFlightList = new List<Tuple<Flight, Flight>>();
            if (string.IsNullOrEmpty(arrivalFilter.Trim()) || string.IsNullOrEmpty(destinationFilter.Trim()))
            {
                return new List<Tuple<Flight, Flight>>();//Return empty List;
            }
            arrivalFilter = arrivalFilter.ToLower();
            destinationFilter = destinationFilter.ToLower();

            List<Flight> firstFlights = flightList.getItems()
                                  .Where(firstFlight => firstFlight.getArrival().ToLower().Contains(arrivalFilter))
                                  .ToList();

            foreach (var firstFlight in firstFlights)
            {
                var nextFlights = flightList.getItems()
                                             .Where(nextFlight => nextFlight.getArrival().ToLower() == firstFlight.getDestination().ToLower() &&
                                                                 nextFlight.getDestination().ToLower().Contains(destinationFilter))
                                             .ToList();
                foreach (var nextFlight in nextFlights)
                {
                    connectingFlightList.Add(new Tuple<Flight, Flight>(firstFlight, nextFlight));
                }

            }
            return connectingFlightList;
        }
        public void updateFlightData(string fileName)
        {
            try
            {
                using StreamWriter writer = new StreamWriter(fileName, false);
                foreach (Flight flight in flightList.getItems())
                {
                    string flightId = Convert.ToString(flight.getId());
                    writer.WriteLine($"{flightId}|{flight.getFlightName()}|{flight.getAirline()}|{flight.getArrival()}|{flight.getDestination()}");
                }
            }
            catch (FileNotFoundException ex)
            {
            }
            catch (Exception ex)
            {
            }
        }
    }
}