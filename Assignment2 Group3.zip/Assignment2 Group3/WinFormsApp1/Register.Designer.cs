﻿namespace WinFormsApp1
{
    partial class RegisterForm
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private ComboBox cmbRole;
        private Button btnRegister;
        private Label lblUsername;
        private Label lblPassword;
        private Label lblRole;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtUsername = new TextBox();
            txtPassword = new TextBox();
            cmbRole = new ComboBox();
            btnRegister = new Button();
            lblUsername = new Label();
            lblPassword = new Label();
            lblRole = new Label();
            SuspendLayout();
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(120, 20);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(196, 31);
            txtUsername.TabIndex = 1;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(120, 86);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(196, 31);
            txtPassword.TabIndex = 3;
            // 
            // cmbRole
            // 
            cmbRole.Location = new Point(120, 151);
            cmbRole.Name = "cmbRole";
            cmbRole.Size = new Size(144, 33);
            cmbRole.TabIndex = 5;
            // 
            // btnRegister
            // 
            btnRegister.Location = new Point(120, 205);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(100, 40);
            btnRegister.TabIndex = 6;
            btnRegister.Text = "Register";
            btnRegister.Click += btnRegister_Click;
            // 
            // lblUsername
            // 
            lblUsername.Location = new Point(20, 20);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(100, 23);
            lblUsername.TabIndex = 0;
            lblUsername.Text = "Username";
            // 
            // lblPassword
            // 
            lblPassword.Location = new Point(20, 86);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(100, 23);
            lblPassword.TabIndex = 2;
            lblPassword.Text = "Password";
            // 
            // lblRole
            // 
            lblRole.Location = new Point(20, 151);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(100, 23);
            lblRole.TabIndex = 4;
            lblRole.Text = "Role";
            // 
            // RegisterForm
            // 
            ClientSize = new Size(393, 295);
            Controls.Add(lblUsername);
            Controls.Add(txtUsername);
            Controls.Add(lblPassword);
            Controls.Add(txtPassword);
            Controls.Add(lblRole);
            Controls.Add(cmbRole);
            Controls.Add(btnRegister);
            Name = "RegisterForm";
            Text = "Register New User";
            Load += RegisterForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
