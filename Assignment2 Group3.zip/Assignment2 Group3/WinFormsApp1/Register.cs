﻿using System;
using System.IO;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class RegisterForm : Form
    {
        private Login loginForm;

        // Constructor that takes a LoginForm instance
        public RegisterForm(Login login)
        {
            InitializeComponent();
            loginForm = login;
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {
            cmbRole.Items.Add("admin");
            cmbRole.Items.Add("user");
            cmbRole.SelectedIndex = 1; // Default to "user"
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string role = cmbRole.SelectedItem.ToString();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and Password cannot be empty.");
                return;
            }

            // Find the maximum ID and increment for new user
            int newId = GetNewUserId();

            // Create the new user line to save to file
            string newUserLine = $"{newId}|{username}|{username}|{password}|{role}";

            // Append the new user to User.txt
            AppendToUserFile(newUserLine);

            MessageBox.Show("User registered successfully!");

            // Close the RegisterForm and show the LoginForm
            this.Close();
            loginForm.Show();
        }

        private int GetNewUserId()
        {
            int maxId = 0;

            // Read through User.txt to find the maximum ID
            if (File.Exists("User.txt"))
            {
                var lines = File.ReadAllLines("User.txt");
                foreach (var line in lines)
                {
                    string[] data = line.Split('|');
                    if (int.TryParse(data[0], out int id))
                    {
                        if (id > maxId)
                            maxId = id;
                    }
                }
            }

            return maxId + 1;
        }

        private void AppendToUserFile(string userLine)
        {
            using (StreamWriter writer = new StreamWriter("User.txt", true))
            {
                writer.WriteLine(userLine);
            }
        }
    }
}

