﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace WinFormsApp1
{
    public class ObjList<T> where T : new()  //Generic Class ObjList<> with T as Generic parameter
    {
        private List<T> itemList;

        public ObjList()
        {
            itemList = new List<T>();
        }
        public void addItem(T item)
        {
            itemList.Add(item);
        }
        public void removeItem(T item)
        {
            itemList.Remove(item);
        }
        public List<T> getItems()
        {
            return itemList;
        }
        public void loadItems(string fileName, Action<T, string> loadItemAction) //
        {
            using (StreamReader content = new StreamReader(fileName)) //Call StreamReader to red file and load data
            {
                while (!content.EndOfStream) //Check until end of file
                {
                    string line = content.ReadLine();
                    if (line != null) //If line is not null or empty
                    {
                        T item = new T();
                        loadItemAction(item, line);
                        itemList.Add(item);
                    }
                }
            }
        }
    }
}
