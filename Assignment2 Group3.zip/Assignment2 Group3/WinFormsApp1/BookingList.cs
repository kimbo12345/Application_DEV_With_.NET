﻿namespace WinFormsApp1
{
    public class BookingList
    {
        private ObjList<Booking> bookingList;

        public BookingList()
        {
            bookingList = new ObjList<Booking>();
        }

        public void loadBookingList(string fileName)
        {
            bookingList.loadItems(fileName, (booking, line) => booking.loadBooking(line));
        }

        public bool hasBooking(int flightId, int connectingFlightId)
        {
            return bookingList.getItems().Any(booking => booking.getConnectingFlightId() == connectingFlightId && booking.getFlightId() == flightId);
        }
        public bool hasBooking(int userId)
        {
            return bookingList.getItems().Any(booking => booking.getUserId() == userId);
        }
        public bool hasBooking(int userId, int firstFlightId, int secondFlightId)
        {
            return bookingList.getItems().Any(booking => booking.getUserId() == userId && booking.getFlightId() == firstFlightId && booking.getConnectingFlightId() == secondFlightId);
        }
        public List<Booking> getBookingList()
        {
            return bookingList.getItems();
        }
        public List<Booking> getBookingList(int userId)
        {
            return bookingList.getItems().Where(booking => booking.getUserId() == userId).ToList();
        }

        public void addBooking(Booking booking)
        {
            bookingList.addItem(booking);
        }

        public void removeBooking(Booking booking)
        {
            bookingList.removeItem(booking);
        }
        public void removeBookingById(int id)
        {
            Booking selectedBooking = bookingList.getItems().FirstOrDefault(tempBooking => tempBooking.getId() == id);
            if (selectedBooking != null)
            {
                bookingList.removeItem(selectedBooking);
            }
        }

        public void triggerRemoveAllBookingWithUserId(int userId)
        {
            bookingList.getItems().RemoveAll(booking =>  booking.getUserId() == userId);
        }

        public void triggerRemoveAllBookingWithFlightId(int flightId)
        {
            bookingList.getItems().RemoveAll(booking => booking.getFlightId() == flightId);
            bookingList.getItems().RemoveAll(booking => booking.getConnectingFlightId() == flightId);   
        }

        public List<int> getBookingIdList()
        {
            return bookingList.getItems().Select(tempBooking => tempBooking.getId()).ToList();
        }

        public Booking getBookingById(int bookingId)
        {
            // bookingList에서 해당 ID를 가진 Booking을 찾아 반환합니다.
            return bookingList.getItems().FirstOrDefault(booking => booking.getId() == bookingId);
        }

        public Booking getBookingByUserId(int userId)
        {
            if (hasBooking(userId))
            {
                return bookingList.getItems().FirstOrDefault(booking => booking.getUserId() == userId);
            }
            else return new Booking();
        }

        public Booking getBookingByFlightId(int flightId)
        {
            if (hasBooking(flightId))
            {
                return bookingList.getItems().FirstOrDefault(flight => flight.getFlightId() == flightId);
            }
            return new Booking();
        }

        public void updateBookingData(string fileName)
        {
            try
            {
                using StreamWriter writer = new StreamWriter(fileName, false);
                foreach (Booking booking in bookingList.getItems())
                {
                    string bookingId = Convert.ToString(booking.getFlightId());
                    string bookingUserId = Convert.ToString(booking.getUserId());
                    string bookingFlightId = Convert.ToString(booking.getFlightId());
                    string bookingConnectingFlightId = Convert.ToString(booking.getConnectingFlightId());
                    writer.WriteLine($"{bookingId}|{bookingUserId}|{bookingFlightId}|{bookingConnectingFlightId}|{booking.getBookingType()}");
                }
            }
            catch (FileNotFoundException ex)
            {
            }
            catch (Exception ex)
            {
            }
        }
    }
}