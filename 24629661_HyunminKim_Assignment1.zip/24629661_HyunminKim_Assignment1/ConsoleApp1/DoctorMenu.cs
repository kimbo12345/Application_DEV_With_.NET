﻿using System;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;

class DoctorMenu : Menu
{
    private string loggedInDoctorId;

    public override void LoginMenu()
    {
        Console.Clear();
        Console.WriteLine("Enter your Doctor ID:");
        string id = Console.ReadLine();

        Console.WriteLine("Enter your password:");
        string password = Utils.HidePassword();

        if (Utils.ValidateCredentials(id, password, "doctor"))
        {
            loggedInDoctorId = id;
            Console.WriteLine("Doctor login successful!");
            ShowMenu();
        }
        else
        {
            Console.WriteLine("Invalid credentials, please try again.");
            LoginMenu();
        }
    }

    public override void ShowMenu()
    {
        bool running = true;
        while (running)
        {
            Console.Clear();
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |        DOTNET Hospital Management System    |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |              Doctor Menu                    |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |1. List Doctor Details                       |");
            Console.WriteLine(" |2. List Patients                             |");
            Console.WriteLine(" |3. List Appointments                         |");
            Console.WriteLine(" |4. Check Particular Patient                  |");
            Console.WriteLine(" |5. List Appointments With Patient            |");
            Console.WriteLine(" |6. Logout                                    |");
            Console.WriteLine(" |7. Exit                                      |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine();
            Console.Write("Enter your choice: ");
            string choice = Console.ReadLine();
            Console.WriteLine($"You selected: {choice}");

            switch (choice)
            {
                case "1":
                    ListDoctorDetails();
                    break;
                case "2":
                    ListPatients();
                    break;
                case "3":
                    ListAppointments();
                    break;
                case "4":
                    CheckParticularPatient();
                    break;
                case "5":
                    ListAppointmentsWithPatient();
                    break;
                case "6":
                    Console.WriteLine("Logging out...");
                    running = false;
                    LoginMenu();
                    break;
                case "7":
                    Console.WriteLine("Exiting application...");
                    running = false;
                    break;
                default:
                    Console.WriteLine("Invalid choice, please try again.");
                    break;
            }

            if (running)
            {
                Console.WriteLine("Press any key to return to the menu...");
                Console.ReadKey();
            }
        }
    }

    private void ListDoctorDetails() // list particular doctor
    {
        string filePath = Utils.GetFilePath("doctor.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic doctors = JsonConvert.DeserializeObject<dynamic>(jsonData);

            foreach (var doctor in doctors)
            {
                if (doctor.ID.ToString() == loggedInDoctorId)
                {
                    Console.Clear();
                    Console.WriteLine(" |────────────────────────────────────────────|");
                    Console.WriteLine(" |            Doctor Details                  |");
                    Console.WriteLine(" |────────────────────────────────────────────|");
                    Console.WriteLine("Full Name: " + doctor.FullName);
                    Console.WriteLine("Specialty: " + doctor.Specialty);
                    Console.WriteLine("Email: " + doctor.Email);
                    Console.WriteLine("Phone: " + doctor.Phone);
                    Console.WriteLine("Address: " + doctor.Address);
                    return;
                }
            }
        }
        else
        {
            Console.WriteLine("Doctor data not found.");
        }
    }

    private void ListPatients() // list particular patient
    {
        string filePath = Utils.GetFilePath("patient.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic patients = JsonConvert.DeserializeObject<dynamic>(jsonData);

            Console.Clear();
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |            Patients List                   |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine("+-----------------------------------+---------------------+-------------------------+");

            foreach (var patient in patients)
            {
                Newtonsoft.Json.Linq.JArray doctorIdsArray = patient.DoctorIDs as Newtonsoft.Json.Linq.JArray;

                if (doctorIdsArray != null)
                {
                    var doctorIdsList = doctorIdsArray.ToObject<List<int>>();
                    if (doctorIdsList != null && doctorIdsList.Contains(int.Parse(loggedInDoctorId)))
                    {
                        Console.WriteLine($"| {patient.FullName,-30} | {patient.Email,-20} | {patient.Phone,-23} |");
                    }
                }
            }
            Console.WriteLine("+-----------------------------------+---------------------+-------------------------+");
        }
        else
        {
            Console.WriteLine("Patient data not found.");
        }
    }

    private void ListAppointments() // list appointments 
    {
        string filePath = Utils.GetFilePath("appointments.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic appointments = JsonConvert.DeserializeObject<dynamic>(jsonData);

            Console.Clear();
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |           Appointments List                |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine("Appointment ID | Patient ID | Doctor ID | Date       | Description");
            Console.WriteLine("-----------------------------------------------------------");

            foreach (var appointment in appointments)
            {
                Console.WriteLine($"{appointment.ID} | {appointment.PatientID} | {appointment.DoctorID} | {appointment.Date} | {appointment.Description}");
            }
        }
        else
        {
            Console.WriteLine("Appointment data not found.");
        }
    }
   
    private void CheckParticularPatient()  // Check Particular Patient
    {
        Console.Clear();
        Console.WriteLine("Enter the Patient ID:");
        string patientID = Console.ReadLine();

        string filePath = Utils.GetFilePath("patient.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic patients = JsonConvert.DeserializeObject<dynamic>(jsonData);

            foreach (var patient in patients)
            {
                if (patient.ID.ToString() == patientID)
                {
                    Console.WriteLine($"Full Name: {patient.FullName}, Email: {patient.Email}, Phone: {patient.Phone}, Address: {patient.Address}");
                    return;
                }
            }
            Console.WriteLine("Patient not found.");
        }
        else
        {
            Console.WriteLine("Patient data not found.");
        }
    }

    private void ListAppointmentsWithPatient()     // List Appointments with Patient 
    {
        Console.Clear();
        Console.WriteLine("Enter the Patient ID:");
        string patientID = Console.ReadLine();

        string filePath = Utils.GetFilePath("appointments.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic appointments = JsonConvert.DeserializeObject<dynamic>(jsonData);

            Console.WriteLine($"Appointments with patient ID: {patientID}");
            foreach (var appointment in appointments)
            {
                if (appointment.PatientID.ToString() == patientID && appointment.DoctorID.ToString() == loggedInDoctorId)
                {
                    Console.WriteLine($"Appointment ID: {appointment.ID}, Description: {appointment.Description}");
                }
            }
        }
        else
        {
            Console.WriteLine("Appointments data not found.");
        }
    }
}
