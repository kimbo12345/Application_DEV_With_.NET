﻿
abstract class Menu
{
    public abstract void ShowMenu();
    public abstract void LoginMenu(); 
}