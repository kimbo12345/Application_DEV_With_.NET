﻿using Newtonsoft.Json;
using System;
using System.IO;
public class JsonFileReader // utility methods for reading from and writing to JSON files 
{
    public static T ReadJson<T>(string filePath) // reads the contents of a JSON
    {
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<T>(jsonData);
        }
        else
        {
            throw new FileNotFoundException("File not found: " + filePath);
        }
    }

    public static void WriteJson<T>(string filePath, T data) // serializes the provided data of type T into JSON format
    {
        string jsonData = JsonConvert.SerializeObject(data, Formatting.Indented);
        File.WriteAllText(filePath, jsonData);
    }
}