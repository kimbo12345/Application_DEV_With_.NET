﻿using System;
using System.IO;
using Newtonsoft.Json;

public static class Utils
{
    // File direction
    public static string GetFilePath(string fileName)
    {
        string basePath = AppDomain.CurrentDomain.BaseDirectory;
        return Path.Combine(basePath, fileName);
    }

    // Hiding password
    public static string HidePassword()
    {
        string password = "";
        ConsoleKeyInfo keyInfo;
        do
        {
            keyInfo = Console.ReadKey(true);
            if (keyInfo.Key != ConsoleKey.Backspace && keyInfo.Key != ConsoleKey.Enter)
            {
                password += keyInfo.KeyChar;
                Console.Write("*");
            }
            else if (keyInfo.Key == ConsoleKey.Backspace && password.Length > 0)
            {
                password = password.Substring(0, password.Length - 1);
                Console.Write("\b \b");
            }
        } while (keyInfo.Key != ConsoleKey.Enter);
        Console.WriteLine();
        return password;
    }

    // Validation (using .json)
    public static bool ValidateCredentials(string id, string password, string userType)
    {
        string filePath = GetFilePath($"{userType}.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic users = JsonConvert.DeserializeObject<dynamic>(jsonData);

            foreach (var user in users)
            {
                if (user.ID.ToString() == id && user.Password.ToString() == password)
                {
                    return true;
                }
            }
        }
        return false;
    }
}
