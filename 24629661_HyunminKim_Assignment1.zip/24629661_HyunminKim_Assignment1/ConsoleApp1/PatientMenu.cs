﻿using System;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;

class PatientMenu : Menu
{
    private string loggedInPatientId;

    public override void LoginMenu()
    {
        Console.Clear();
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine(" |        DOTNET Hospital Management System    |");
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine(" |              Patient Login                 |");
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine("Enter your Patient ID:");
        string id = Console.ReadLine();

        Console.WriteLine("Enter your password:");
        string password = Utils.HidePassword();

        if (Utils.ValidateCredentials(id, password, "patient"))
        {
            loggedInPatientId = id;
            Console.WriteLine("Patient login successful!");
            ShowMenu();
        }
        else
        {
            Console.WriteLine("Invalid credentials, please try again.");
            LoginMenu();
        }
    }

    public override void ShowMenu()
    {
        bool running = true;
        while (running)
        {
            Console.Clear();
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |        DOTNET Hospital Management System    |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |             Patient Menu                   |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |1. List Patient Details                     |");
            Console.WriteLine(" |2. List My Doctor Details                   |");
            Console.WriteLine(" |3. List All Appointments                    |");
            Console.WriteLine(" |4. Book Appointment                         |");
            Console.WriteLine(" |5. Logout                                   |");
            Console.WriteLine(" |6. Exit                                     |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine();
            Console.Write("Enter your choice: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    ListPatientDetails();
                    break;
                case "2":
                    ListMyDoctorDetails();
                    break;
                case "3":
                    ListAllAppointments();
                    break;
                case "4":
                    BookAppointment();
                    break;
                case "5":
                    running = false;
                    LoginMenu();
                    break;
                case "6":
                    running = false;
                    break;
                default:
                    Console.WriteLine("Invalid choice, please try again.");
                    break;
            }

            if (running)
            {
                Console.WriteLine("Press any key to return to the menu...");
                Console.ReadKey();
            }
        }
    }
    private void ListPatientDetails()  // retrieves the logged-in patient's details from a JSON file and displays them
    {
        string filePath = Utils.GetFilePath("patient.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic patients = JsonConvert.DeserializeObject<dynamic>(jsonData);

            foreach (var patient in patients)
            {
                if (patient.ID == loggedInPatientId)
                {
                    Console.WriteLine($"ID: {patient.ID}, FullName: {patient.FullName}, Address: {patient.Address}, Email: {patient.Email}, Phone: {patient.Phone}");

                    if (patient.DoctorIDs != null)
                    {
                        Console.WriteLine($"Doctor IDs: {string.Join(", ", patient.DoctorIDs)}");
                    }
                    else
                    {
                        Console.WriteLine("No associated doctors.");
                    }

                    if (patient.Descriptions != null)
                    {
                        Console.WriteLine($"Descriptions: {string.Join(", ", patient.Descriptions)}");
                    }
                    else
                    {
                        Console.WriteLine("No descriptions available.");
                    }

                    Console.WriteLine();
                }
            }
        }
        else
        {
            Console.WriteLine("Patient data not found.");
        }
    }

    private void ListMyDoctorDetails() // retrieves and displays the details of the doctors associated with the logged-in patient.
    {
        string patientFilePath = Utils.GetFilePath("patient.json");
        string doctorFilePath = Utils.GetFilePath("doctor.json");

        if (File.Exists(patientFilePath) && File.Exists(doctorFilePath))
        {
            string patientData = File.ReadAllText(patientFilePath);
            dynamic patients = JsonConvert.DeserializeObject<dynamic>(patientData);

            string doctorData = File.ReadAllText(doctorFilePath);
            dynamic doctors = JsonConvert.DeserializeObject<dynamic>(doctorData);

            foreach (var patient in patients)
            {
                if (patient.ID == loggedInPatientId)
                {
                    Console.WriteLine($"Patient ID: {patient.ID}");

                    if (patient.DoctorIDs != null)
                    {
                        foreach (var doctorId in patient.DoctorIDs)
                        {
                            foreach (var doctor in doctors)
                            {
                                if (doctor.ID == doctorId)
                                {
                                    Console.WriteLine($"Doctor ID: {doctor.ID}, FullName: {doctor.FullName}, Specialty: {doctor.Specialty}");
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("This patient has no associated doctors.");
                    }
                }
            }
        }
        else
        {
            Console.WriteLine("Doctor or patient data not found.");
        }
    }

    private void ListAllAppointments() // retrieves all the appointments associated with the logged-in patient from a JSON file and displays them.
    {
        string filePath = Utils.GetFilePath("appointments.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic appointments = JsonConvert.DeserializeObject<dynamic>(jsonData);

            foreach (var appointment in appointments)
            {
                if (appointment.PatientID == loggedInPatientId)
                {
                    Console.WriteLine($"Appointment ID: {appointment.ID}, Doctor ID: {appointment.DoctorID}, Date: {appointment.Date}, Description: {appointment.Description}");
                }
            }
        }
        else
        {
            Console.WriteLine("Appointment data not found.");
        }
    }

    private void BookAppointment() //creates a new appointment for the logged-in patient and saves it 
    {
        string filePath = Utils.GetFilePath("appointments.json");

        dynamic newAppointment = new
        {
            ID = 123,
            PatientID = loggedInPatientId,
            DoctorID = 2,
            Date = "2024-10-10",
            Description = "Checkup"
        };

        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            List<dynamic> appointments = JsonConvert.DeserializeObject<List<dynamic>>(jsonData);
            appointments.Add(newAppointment);
            File.WriteAllText(filePath, JsonConvert.SerializeObject(appointments, Formatting.Indented));
            Console.WriteLine("Appointment booked successfully.");
        }
        else
        {
            var appointments = new List<dynamic> { newAppointment };
            File.WriteAllText(filePath, JsonConvert.SerializeObject(appointments, Formatting.Indented));
            Console.WriteLine("Appointment booked and new appointment file created.");
        }
    }
}