﻿using System;
using Newtonsoft.Json;
using System.IO;

class AdminMenu : Menu // Responsible for managing administrative actions
{
    public override void LoginMenu() // prompts the admin for their credentials 
    {
        Console.Clear();
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine(" |        DOTNET Hospital Management System    |");
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine(" |               Admin Login                  |");
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine("Enter your Admin ID:");
        string id = Console.ReadLine();

        Console.WriteLine("Enter your password:");
        string password = Utils.HidePassword();

        if (Utils.ValidateCredentials(id, password, "admin"))
        {
            Console.WriteLine("Admin login successful!");
            ShowMenu();
        }
        else
        {
            Console.WriteLine("Invalid credentials, please try again.");
            LoginMenu();
        }
    }

    public override void ShowMenu()
    {
        bool running = true;
        while (running)
        {
            Console.Clear();
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |        DOTNET Hospital Management System    |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |              Admin Menu                    |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |1. List All Doctors                         |");
            Console.WriteLine(" |2. Check Doctor Details                     |");
            Console.WriteLine(" |3. List All Patients                        |");
            Console.WriteLine(" |4. Check Patient Details                    |");
            Console.WriteLine(" |5. Add Doctor                               |");
            Console.WriteLine(" |6. Add Patient                              |");
            Console.WriteLine(" |7. Logout                                   |");
            Console.WriteLine(" |8. Exit                                     |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine();
            Console.Write("Enter your choice: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    ListAllDoctors();
                    break;
                case "2":
                    CheckDoctorDetails();
                    break;
                case "3":
                    ListAllPatients();
                    break;
                case "4":
                    CheckPatientDetails();
                    break;
                case "5":
                    AddDoctor();
                    break;
                case "6":
                    AddPatient();
                    break;
                case "7":
                    running = false;
                    LoginMenu();
                    break;
                case "8":
                    running = false;
                    break;
                default:
                    Console.WriteLine("Invalid choice, please try again.");
                    break;
            }

            if (running)
            {
                Console.WriteLine("Press any key to return to the menu...");
                Console.ReadKey();
            }
        }
    }

    private void ListAllDoctors() // retrieves a list of doctors from a JSON file and displays their details
    {
        string filePath = Utils.GetFilePath("doctor.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic doctors = JsonConvert.DeserializeObject<dynamic>(jsonData);

            Console.Clear();
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |         DOTNET Hospital Management System   |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |               All Doctors                  |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" Name                     | Email                   | Phone           | Address ");
            Console.WriteLine("───────────────────────────────────────────────────────────────────────────────");

            foreach (var doctor in doctors)
            {
                Console.WriteLine($"{doctor.FullName,-25} | {doctor.Email,-22} | {doctor.Phone,-14} | {doctor.Address}");
            }
        }
        else
        {
            Console.WriteLine("Doctor data not found.");
        }
    }

    private void CheckDoctorDetails() // allows the admin to enter a doctor's ID to view specific details about that doctor.
    {
        Console.WriteLine("Enter doctor ID to check:");
        string doctorID = Console.ReadLine();

        string filePath = Utils.GetFilePath("doctor.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic doctors = JsonConvert.DeserializeObject<dynamic>(jsonData);

            foreach (var doctor in doctors)
            {
                if (doctor.ID.ToString() == doctorID)
                {
                    Console.Clear();
                    Console.WriteLine(" |────────────────────────────────────────────|");
                    Console.WriteLine(" |         DOTNET Hospital Management System   |");
                    Console.WriteLine(" |────────────────────────────────────────────|");
                    Console.WriteLine(" |              Doctor Details                |");
                    Console.WriteLine(" |────────────────────────────────────────────|");
                    Console.WriteLine($"ID: {doctor.ID}");
                    Console.WriteLine($"FullName: {doctor.FullName}");
                    Console.WriteLine($"Specialty: {doctor.Specialty}");
                    return;
                }
            }

            Console.WriteLine("Doctor not found.");
        }
        else
        {
            Console.WriteLine("Doctor data not found.");
        }
    }

    private void ListAllPatients() // retrieves and displays a list of all patients from a JSON file.
    {
        string filePath = Utils.GetFilePath("patient.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic patients = JsonConvert.DeserializeObject<dynamic>(jsonData);

            Console.Clear();
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |         DOTNET Hospital Management System   |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" |               All Patients                 |");
            Console.WriteLine(" |────────────────────────────────────────────|");
            Console.WriteLine(" Name                     | Email                   | Phone           | Address ");
            Console.WriteLine("───────────────────────────────────────────────────────────────────────────────");

            foreach (var patient in patients)
            {
                Console.WriteLine($"{patient.FullName,-25} | {patient.Email,-22} | {patient.Phone,-14} | {patient.Address}");
            }
        }
        else
        {
            Console.WriteLine("Patient data not found.");
        }
    }

    private void CheckPatientDetails() // enables the admin to enter a patient ID to retrieve and display the details of a specific patient.
    {
        Console.WriteLine("Enter patient ID to check:");
        string patientID = Console.ReadLine();

        string filePath = Utils.GetFilePath("patient.json");
        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            dynamic patients = JsonConvert.DeserializeObject<dynamic>(jsonData);

            foreach (var patient in patients)
            {
                if (patient.ID.ToString() == patientID)
                {
                    Console.Clear();
                    Console.WriteLine(" |────────────────────────────────────────────|");
                    Console.WriteLine(" |         DOTNET Hospital Management System   |");
                    Console.WriteLine(" |────────────────────────────────────────────|");
                    Console.WriteLine(" |             Patient Details                |");
                    Console.WriteLine(" |────────────────────────────────────────────|");
                    Console.WriteLine($"ID: {patient.ID}");
                    Console.WriteLine($"FullName: {patient.FullName}");
                    Console.WriteLine($"Address: {patient.Address}");
                    Console.WriteLine($"Email: {patient.Email}");
                    Console.WriteLine($"Phone: {patient.Phone}");
                    return;
                }
            }

            Console.WriteLine("Patient not found.");
        }
        else
        {
            Console.WriteLine("Patient data not found.");
        }
    }

    private void AddDoctor() // always new doctor ID + 1 so it does not get duplicated
    {
        string filePath = Utils.GetFilePath("doctor.json");

        int newDoctorId = 1;

        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            var doctors = JsonConvert.DeserializeObject<List<dynamic>>(jsonData);

            if (doctors.Count > 0)
            {
                newDoctorId = doctors.Max(d => (int)d.ID) + 1;
            }

            var newDoctor = new
            {
                ID = newDoctorId,
                FullName = "Dr. New Doctor",
                Specialty = "General"
            };

            doctors.Add(newDoctor);
            File.WriteAllText(filePath, JsonConvert.SerializeObject(doctors, Formatting.Indented));
            Console.WriteLine("Doctor added successfully.");
        }
        else
        {
            var doctors = new List<dynamic>
        {
            new
            {
                ID = newDoctorId,
                FullName = "Dr. New Doctor",
                Specialty = "General"
            }
        };
            File.WriteAllText(filePath, JsonConvert.SerializeObject(doctors, Formatting.Indented));
            Console.WriteLine("Doctor added and new doctor file created.");
        }
    }

    private void AddPatient() // always new patient ID + 1 so it does not get duplicated
    {
        string filePath = Utils.GetFilePath("patient.json");

        
        int newPatientId = 1;

        if (File.Exists(filePath))
        {
            string jsonData = File.ReadAllText(filePath);
            var patients = JsonConvert.DeserializeObject<List<dynamic>>(jsonData);

            if (patients.Count > 0)
            {
                
                newPatientId = patients.Max(p => (int)p.ID) + 1;
            }

            
            var newPatient = new
            {
                ID = newPatientId,
                FullName = "New Patient",
                Address = "New Address",
                Email = "newpatient@example.com",
                Phone = "123-456-7890"
            };

            
            patients.Add(newPatient);
            File.WriteAllText(filePath, JsonConvert.SerializeObject(patients, Formatting.Indented));
            Console.WriteLine("Patient added successfully.");
        }
        else
        {
            
            var patients = new List<dynamic>
        {
            new
            {
                ID = newPatientId,
                FullName = "New Patient",
                Address = "New Address",
                Email = "newpatient@example.com",
                Phone = "123-456-7890"
            }
        };
            File.WriteAllText(filePath, JsonConvert.SerializeObject(patients, Formatting.Indented));
            Console.WriteLine("Patient added and new patient file created.");
        }
    }

}