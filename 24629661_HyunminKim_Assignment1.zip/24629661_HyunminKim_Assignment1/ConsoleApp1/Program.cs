﻿using System;

class Program //This class serves as the entry point for the hospital management system.

{
    static void Main(string[] args)
    {
        Console.Clear();
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine(" |        DOTNET Hospital Management System    |");
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine(" |            Welcome to the System           |");
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine(" | Please select user type to login:          |");
        Console.WriteLine(" |────────────────────────────────────────────|");
        Console.WriteLine(" |1. Patient                                  |");
        Console.WriteLine(" |2. Doctor                                   |");
        Console.WriteLine(" |3. Admin                                    |");
        Console.WriteLine(" |4. Exit                                     |");
        Console.WriteLine(" |────────────────────────────────────────────|");

        string choice = Console.ReadLine();
        switch (choice)
        {
            case "1":
                PatientMenu patientMenu = new PatientMenu();
                patientMenu.LoginMenu();
                break;
            case "2":
                DoctorMenu doctorMenu = new DoctorMenu();
                doctorMenu.LoginMenu();
                break;
            case "3":
                AdminMenu adminMenu = new AdminMenu();
                adminMenu.LoginMenu();
                break;
            case "4":
                Console.WriteLine("Exiting the system...");
                return;
            default:
                Console.WriteLine("Invalid choice, please try again.");
                break;
        }
    }
}

